//
//  ContentView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import SwiftUI

//index du prj, permet de rentrer dans l'app
struct ContentView: View {
    
    var body: some View {
        NavigationStack {
            ZStack {
                //background
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.6), Color.blue]),
                               startPoint: .top,
                               endPoint: .bottom)
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    //affichage du fruit avec la card
                    TabView {
                        FruitCardView(imageName: "blueberry", title: "Blueberry", description: "Blueberries are sweet, nutritious and wildly popular fruit all over the world.")
                    }
                    .tabViewStyle(.page)
                    //btn de nav
                    NavigationLink(destination: FruitListView()) {
                        HStack {
                            Text("Start")
                            Image(systemName: "arrow.right.circle")
                        }
                        .padding(.horizontal, 40)
                        .padding(.vertical, 15)
                        .background(Capsule().strokeBorder(Color.white, lineWidth: 2))
                        .foregroundColor(.white)
                    }
                }
                .padding(.bottom, 50)
            }
        }
    }
}
#Preview {
    ContentView()
}
