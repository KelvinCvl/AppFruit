//
//  Fruit.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import Foundation

//modèle de fruit
struct Fruit: Identifiable, Codable {
    var id = UUID()
    let name: String
    let description: String
    let imageName: String
    
    enum CodingKeys: String, CodingKey {
        case name
        case description
        case imageName
    }
}
