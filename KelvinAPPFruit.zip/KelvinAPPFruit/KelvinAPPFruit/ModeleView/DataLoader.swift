//
//  DataLoader.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import Foundation

let fruitsData: [Fruit] = load("FruitData.plist")

//loader qui permet de récupérer les data du plist avec gestion des erreurs
func load<T: Decodable>(_ filename: String) -> T {
    let data: Data
    
    guard let file = Bundle.main.url(forResource: filename, withExtension: nil)
    else {
        fatalError("Impossible de trouver \(filename) dans le bundle principal.")
    }
    
    do {
        data = try Data(contentsOf: file)
    } catch {
        fatalError("Impossible de charger \(filename) : \(error)")
    }
    
    do {
        let decoder = PropertyListDecoder()
        return try decoder.decode(T.self, from: data)
    } catch {
        fatalError("Impossible de décoder \(filename) : \(error)")
    }
}
