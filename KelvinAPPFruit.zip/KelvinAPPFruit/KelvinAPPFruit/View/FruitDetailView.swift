//
//  FruitDetailView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//
import SwiftUI
//page de détails 
struct FruitDetailView: View {
    var fruit: Fruit

    var body: some View {
        ScrollView(.vertical, showsIndicators: false) {
            VStack(alignment: .center, spacing: 20) {
                //img avec fond
                ZStack {
                    LinearGradient(colors: [.orange, .red], startPoint: .topLeading, endPoint: .bottomTrailing)
                    
                    Image(fruit.imageName)
                        .resizable()
                        .scaledToFit()
                        .shadow(color: Color.black.opacity(0.15), radius: 8, x: 6, y: 8)
                        .padding(.vertical, 20)
                }
                .frame(height: 440)
                //details
                VStack(alignment: .leading, spacing: 20) {
                    Text(fruit.name)
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.orange)
                    
                    Text(fruit.description)
                        .font(.headline)
                        .multilineTextAlignment(.leading)
                    //info nutrition
                    FruitNutritionalView(fruit: fruit)
                    
                    Text("Learn more about \(fruit.name)".uppercased())
                        .fontWeight(.bold)
                        .foregroundColor(.orange)

                    Text("The \(fruit.name) is a delicious fruit that provides many health benefits. It is rich in vitamins and minerals essential for the body.")
                        .font(.footnote)
                        .multilineTextAlignment(.leading)
                }
                .padding(.horizontal, 20)
                .frame(maxWidth: 640, alignment: .center)
            }
        }
        .ignoresSafeArea(edges: .top)
    }
}

#Preview {
    FruitDetailView(fruit: fruitsData[0])
}

