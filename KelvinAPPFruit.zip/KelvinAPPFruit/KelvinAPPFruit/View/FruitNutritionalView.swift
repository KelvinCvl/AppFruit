//
//  FruitNutritionalView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import SwiftUI
//card d'info de nutrition
struct FruitNutritionalView: View {
    let fruit: Fruit
    let nutrients: [String] = ["Energy", "Sugar", "Fat", "Protein", "Vitamins", "Minerals"]
    
    var body: some View {
        GroupBox() {
            DisclosureGroup("Nutritional value per 100g") {
                ForEach(0..<nutrients.count, id: \.self) { item in
                    Divider().padding(.vertical, 2)
                    HStack {
                        Group {
                            Image(systemName: "info.circle")
                            Text(nutrients[item])
                        }
                        .foregroundColor(.orange)
                        .font(.system(.body).bold())
                        
                        Spacer(minLength: 25)
                        
                        Text("Données test")
                            .multilineTextAlignment(.trailing)
                    }
                }
            }
        }
    }
}

#Preview {
    FruitNutritionalView(fruit: fruitsData[0])
        .preferredColorScheme(.dark)
        .padding()
}
