//
//  FruitCardView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//
import SwiftUI
//organisation de l'affichage du fruit
struct FruitCardView: View {
    let imageName: String
    let title: String
    let description: String
    
    var body: some View {
        VStack(spacing: 20) {
            Image(imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 300)
                .shadow(radius: 10)
            
            Text(title)
                .font(.largeTitle)
                .fontWeight(.heavy)
                .foregroundColor(.white)
            
            Text(description)
                .font(.headline)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 30)
                .foregroundColor(.white)
        }
    }
}

#Preview {
    if !fruitsData.isEmpty {
        FruitCardView(
            imageName: fruitsData[0].imageName,
            title: fruitsData[0].name,
            description: fruitsData[0].description
        )
        .background(Color.orange)
    } else {
        Text("Erreur : Le Plist est vide ou mal chargé")
    }
}
