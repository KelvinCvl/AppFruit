//
//  KelvinAPPFruitApp.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import SwiftUI

@main
struct KelvinAPPFruitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
