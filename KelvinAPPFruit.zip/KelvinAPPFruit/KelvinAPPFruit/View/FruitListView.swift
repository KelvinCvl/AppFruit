//
//  FruitListView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import SwiftUI
//page de la liste des fruits
struct FruitListView: View {
    @State private var isShowingSettings: Bool = false

    var body: some View {
        //card de chaque fruit avec nav vers leur page de detail
        NavigationStack {
            List(fruitsData) { item in
                NavigationLink(destination: FruitDetailView(fruit: item)) {
                    FruitRowView(fruit: item)
                        .padding(.vertical, 4)
                }
            }
            .navigationTitle("Fruits")
            .toolbar {

                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        isShowingSettings = true
                    } label: {
                        Image(systemName: "slider.horizontal.3")
                    }
                }
            }
            //acces aux paramètres
            .sheet(isPresented: $isShowingSettings) {
                SettingsView()
            }
        }
    }
}

#Preview {
    FruitListView()
}
