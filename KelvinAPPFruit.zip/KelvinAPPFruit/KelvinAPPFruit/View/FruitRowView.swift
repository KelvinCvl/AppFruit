//
//  FruitRowView.swift
//  KelvinAPPFruit
//
//  Created by COURS on 20/02/2026.
//

import SwiftUI
//cards des fruits affichées dans la page de la liste
struct FruitRowView: View {
    let fruit: Fruit
    
    var body: some View {
        HStack(spacing: 15) {
            Image(fruit.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: 80, height: 80)
                .background(LinearGradient(colors: [.orange, .red], startPoint: .top, endPoint: .bottom)) 
                .cornerRadius(8)
            
            VStack(alignment: .leading, spacing: 5) {
                Text(fruit.name)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(fruit.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
        }
    }
}

#Preview {
    FruitRowView(fruit: fruitsData[1])
        .padding()
        .previewLayout(.sizeThatFits)
}
 
